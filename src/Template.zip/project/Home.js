import React from 'react'
import './sample.css'
function Home() {
  return (
    <>
    <h1 className="head1">Home</h1>
    <p style={{color:'red'}}>Sri Krishna College of Technology aspires to be recognized as one of the pioneers in imparting world class technical education through technology enabled innovative teaching learning processes with a focus on research activities to cater, to the societal needs.</p>
    </>
  )
}

export default Home