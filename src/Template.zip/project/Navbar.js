import { Outlet, Link } from "react-router-dom";

const Navbar = () => {
  return (
    <>
      <div style={{color:'red'}}>
       
            <Link to="/">Home            </Link>
         
            <Link to="/aboutus"> AboutUs               </Link>
          
            <Link to="/contactus">Contact</Link>
         
      </div>

      <Outlet />
    </>
  )
};

export default Navbar;